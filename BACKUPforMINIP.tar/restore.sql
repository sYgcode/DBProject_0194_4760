--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4 (Debian 17.4-1.pgdg120+2)
-- Dumped by pg_dump version 17.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: myuser
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO myuser;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: myuser
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hangar; Type: TABLE; Schema: public; Owner: myuser
--

CREATE TABLE public.hangar (
    hangar_id integer NOT NULL,
    location character varying(80) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.hangar OWNER TO myuser;

--
-- Name: hub; Type: TABLE; Schema: public; Owner: myuser
--

CREATE TABLE public.hub (
    hub_id integer NOT NULL,
    name character varying(50) NOT NULL,
    location character varying(80) NOT NULL,
    iata_code character varying(10) NOT NULL,
    capacity integer NOT NULL
);


ALTER TABLE public.hub OWNER TO myuser;

--
-- Name: operator; Type: TABLE; Schema: public; Owner: myuser
--

CREATE TABLE public.operator (
    operator_id integer NOT NULL,
    name character varying(50) NOT NULL,
    type character varying(30) NOT NULL,
    fleet_size integer NOT NULL,
    hub_id integer NOT NULL
);


ALTER TABLE public.operator OWNER TO myuser;

--
-- Name: pilot; Type: TABLE; Schema: public; Owner: myuser
--

CREATE TABLE public.pilot (
    pilot_id integer NOT NULL,
    name character varying(50) NOT NULL,
    license_num character varying(30) NOT NULL,
    rank character varying(20) NOT NULL,
    experience integer NOT NULL,
    operator_id integer NOT NULL
);


ALTER TABLE public.pilot OWNER TO myuser;

--
-- Name: pilot_plane; Type: TABLE; Schema: public; Owner: myuser
--

CREATE TABLE public.pilot_plane (
    assignment_date date NOT NULL,
    plane_id integer NOT NULL,
    pilot_id integer NOT NULL
);


ALTER TABLE public.pilot_plane OWNER TO myuser;

--
-- Name: plane; Type: TABLE; Schema: public; Owner: myuser
--

CREATE TABLE public.plane (
    plane_id integer NOT NULL,
    model character varying(25) NOT NULL,
    productiondate date NOT NULL,
    capacity integer NOT NULL,
    maxaltitude integer NOT NULL,
    maxdistance integer NOT NULL,
    status character varying(30) NOT NULL,
    producer_id integer NOT NULL,
    hangar_id integer NOT NULL,
    operator_id integer NOT NULL
);


ALTER TABLE public.plane OWNER TO myuser;

--
-- Name: producer; Type: TABLE; Schema: public; Owner: myuser
--

CREATE TABLE public.producer (
    producer_id integer NOT NULL,
    pname character varying(50) NOT NULL,
    estdate date NOT NULL,
    owner character varying(50) NOT NULL
);


ALTER TABLE public.producer OWNER TO myuser;

--
-- Data for Name: hangar; Type: TABLE DATA; Schema: public; Owner: myuser
--

COPY public.hangar (hangar_id, location, name) FROM stdin;
\.
COPY public.hangar (hangar_id, location, name) FROM '$$PATH$$/3399.dat';

--
-- Data for Name: hub; Type: TABLE DATA; Schema: public; Owner: myuser
--

COPY public.hub (hub_id, name, location, iata_code, capacity) FROM stdin;
\.
COPY public.hub (hub_id, name, location, iata_code, capacity) FROM '$$PATH$$/3401.dat';

--
-- Data for Name: operator; Type: TABLE DATA; Schema: public; Owner: myuser
--

COPY public.operator (operator_id, name, type, fleet_size, hub_id) FROM stdin;
\.
COPY public.operator (operator_id, name, type, fleet_size, hub_id) FROM '$$PATH$$/3402.dat';

--
-- Data for Name: pilot; Type: TABLE DATA; Schema: public; Owner: myuser
--

COPY public.pilot (pilot_id, name, license_num, rank, experience, operator_id) FROM stdin;
\.
COPY public.pilot (pilot_id, name, license_num, rank, experience, operator_id) FROM '$$PATH$$/3404.dat';

--
-- Data for Name: pilot_plane; Type: TABLE DATA; Schema: public; Owner: myuser
--

COPY public.pilot_plane (assignment_date, plane_id, pilot_id) FROM stdin;
\.
COPY public.pilot_plane (assignment_date, plane_id, pilot_id) FROM '$$PATH$$/3405.dat';

--
-- Data for Name: plane; Type: TABLE DATA; Schema: public; Owner: myuser
--

COPY public.plane (plane_id, model, productiondate, capacity, maxaltitude, maxdistance, status, producer_id, hangar_id, operator_id) FROM stdin;
\.
COPY public.plane (plane_id, model, productiondate, capacity, maxaltitude, maxdistance, status, producer_id, hangar_id, operator_id) FROM '$$PATH$$/3403.dat';

--
-- Data for Name: producer; Type: TABLE DATA; Schema: public; Owner: myuser
--

COPY public.producer (producer_id, pname, estdate, owner) FROM stdin;
\.
COPY public.producer (producer_id, pname, estdate, owner) FROM '$$PATH$$/3400.dat';

--
-- Name: hangar hangar_pkey; Type: CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.hangar
    ADD CONSTRAINT hangar_pkey PRIMARY KEY (hangar_id);


--
-- Name: hub hub_pkey; Type: CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.hub
    ADD CONSTRAINT hub_pkey PRIMARY KEY (hub_id);


--
-- Name: operator operator_pkey; Type: CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.operator
    ADD CONSTRAINT operator_pkey PRIMARY KEY (operator_id);


--
-- Name: pilot pilot_pkey; Type: CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.pilot
    ADD CONSTRAINT pilot_pkey PRIMARY KEY (pilot_id);


--
-- Name: pilot_plane pilot_plane_pkey; Type: CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.pilot_plane
    ADD CONSTRAINT pilot_plane_pkey PRIMARY KEY (plane_id, pilot_id);


--
-- Name: plane plane_pkey; Type: CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.plane
    ADD CONSTRAINT plane_pkey PRIMARY KEY (plane_id);


--
-- Name: producer producer_pkey; Type: CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.producer
    ADD CONSTRAINT producer_pkey PRIMARY KEY (producer_id);


--
-- Name: operator operator_hub_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.operator
    ADD CONSTRAINT operator_hub_id_fkey FOREIGN KEY (hub_id) REFERENCES public.hub(hub_id);


--
-- Name: pilot pilot_operator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.pilot
    ADD CONSTRAINT pilot_operator_id_fkey FOREIGN KEY (operator_id) REFERENCES public.operator(operator_id);


--
-- Name: pilot_plane pilot_plane_pilot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.pilot_plane
    ADD CONSTRAINT pilot_plane_pilot_id_fkey FOREIGN KEY (pilot_id) REFERENCES public.pilot(pilot_id);


--
-- Name: pilot_plane pilot_plane_plane_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.pilot_plane
    ADD CONSTRAINT pilot_plane_plane_id_fkey FOREIGN KEY (plane_id) REFERENCES public.plane(plane_id);


--
-- Name: plane plane_hangar_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.plane
    ADD CONSTRAINT plane_hangar_id_fkey FOREIGN KEY (hangar_id) REFERENCES public.hangar(hangar_id);


--
-- Name: plane plane_operator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.plane
    ADD CONSTRAINT plane_operator_id_fkey FOREIGN KEY (operator_id) REFERENCES public.operator(operator_id);


--
-- Name: plane plane_producer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: myuser
--

ALTER TABLE ONLY public.plane
    ADD CONSTRAINT plane_producer_id_fkey FOREIGN KEY (producer_id) REFERENCES public.producer(producer_id);


--
-- PostgreSQL database dump complete
--

